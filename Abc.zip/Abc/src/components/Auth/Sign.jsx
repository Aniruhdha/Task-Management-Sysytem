import React, { useState } from 'react'

const Sign = ({handleLogin}) => {
    const [email, setEmail] = useState('')    
    const [password, setPassword] = useState('')  
    const SubmitHandler=(e)=>{
        e.preventDefault()
        handleLogin(email,password)
        setEmail("")
        setPassword("")



    }
  return (
    <div className='flex items-center justify-center h-screen w-screen'>
        <div className='border-2 border-emerald-600 p-20 rounded-xl'>
            <form
            onSubmit={(e)=>{
                SubmitHandler(e)
            }
        }
             className='flex flex-col items-center jutify-center '>
                <input  
                value={email}
                onChange={(e)=>{
                    setEmail(e.target.value)
                }}
                required 
                className='text-white outline-none bg-transparent text-xl border-2 border-emerald-600 rounded-full py-4 px-5 placeholder:text-white' type="Email" placeholder='Enter your Email' />
                <input 
                value={password}
                onChange={(e)=>{
                    setPassword(e.target.value)
                }}
                required 
                 className=' text-white outline-none bg-transparent text-xl mt-3 border-2 border-emerald-600 rounded-full py-4 px-5 placeholder:text-white' type="Password" placeholder='Enter your password' />
                <button className='text-white hover:bg-emerald-700 outline-none mt-7  text-xl border-none bg-emerald-600 rounded-full py-6 px-8 placeholder:text-white w-full'>Login</button>
            </form>
        </div>
    </div>
  )
}

export default Sign

