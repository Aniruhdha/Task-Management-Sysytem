import React from 'react'

const AceptedTask = ({data}) => {
  
  return (
    <div className=' flex-shrink-0 h-full w-[250px] rounded-xl bg-green-500 p-5'>
    <div className='flex justify-between justify-center'>
     <h3 className='bg-red-600 text-sm rounded px-3 py-1'>{data.category}</h3>
     <h4>{data.taskDate}</h4>
    </div>
    <h2 className='font-semibold text-xl mt-5'>{data.taskTitle}</h2>
    <p className='text-sm'>{data.taskDescription}</p>
    <div className='flex justify-between mt-7 gap-2'>
    <button className='bg-yellow-600 py-1 px-2 text-sm rounded'>Mark as  completed </button>
    <button className= 'bg-red-600 py-1 px-2 text-sm rounded' >Mark as Failed </button>
 
    </div>
  </div>
  )
}

export default AceptedTask
