import React from 'react'
import AceptedTask from './AceptedTask'
import NewTask from './NewTask'
import FailedTask from './FailedTask'
import CompleteTask from './CompleteTask'

const Tasklist2 = ({data}) => {
  return (
    <div id='Tasklist' className='w-full overflow-x-auto h-[55%]  mt-10 flex justify-start item-center gap-5 justify-nowrap'>
      {data.tasks.map((elem,idx)=>{
          if(elem.active){
            return <AceptedTask key = {idx} data ={elem}/>
          }
          if(elem.newTask){
            return <NewTask key = {idx} data ={elem}/>
          }
          if(elem.completed){
            return <CompleteTask key = {idx} data ={elem}/>
          }
          if(elem.failed){
            return <FailedTask key = {idx} data ={elem}/>
          }
      })}
    </div>
    
  )
}

export default Tasklist2
