import React from 'react'

const FailedTask = ({data}) => {
  return (
    <div className=' flex-shrink-0 h-full w-[250px] rounded-xl bg-red-500 p-5'>
    <div className='flex justify-between justify-center'>
     <h3 className='bg-red-600 text-sm rounded px-3 py-1'>{data.category}</h3>
     <h4>31 oct 2024</h4>
    </div>
    <h2 className='font-semibold text-xl mt-5'>{data.taskTitle}</h2>
    <p className='text-sm'>{data.taskDecription}</p>
    <div className='flex mt-7'>
    <button className='bg-metailc-600 py-1 px-2 text-sm rounded w-[45%]'>Mark as Failed</button>
    </div>
 </div>
  )
}

export default FailedTask
