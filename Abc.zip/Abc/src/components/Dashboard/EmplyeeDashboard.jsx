import React from 'react'
import Header from '../others/Header'
import Tasklist from '../others/Tasklist'
import Tasklist2 from '../TaskList/Tasklist2'

const EmplyeeDashboard = (props) => {
  return (
    <div className='p-20 bg-[#1C1C1C] h-screen '>
      <Header changeUser = {props.changeUser} data  = {props.data}/>
      <Tasklist data  = {props.data} />
      <Tasklist2 data  = {props.data}/>
    </div>
  )
}

export default EmplyeeDashboard
